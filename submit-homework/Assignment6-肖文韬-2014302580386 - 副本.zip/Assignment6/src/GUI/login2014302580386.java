package GUI;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;


public class login2014302580386 extends JFrame{
	Container c = getContentPane();
	
	public login2014302580386(){
		setTitle("Login");
		c.setLayout(null);
		setBounds(300, 200, 300, 180);
		//setVisible(true);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		
		
		JLabel jl=new JLabel("�û�����");
		jl.setBounds(10, 10, 200, 25);
		final JTextField name=new JTextField();
		name.setBounds(80, 10, 150, 25);
		JLabel jl2=new JLabel("���룺");
		jl2.setBounds(10, 50, 200, 25);
		final JPasswordField password=new JPasswordField();
		password.setBounds(80, 50, 150, 25);
		
		c.add(jl);
		c.add(name);
		c.add(jl2);
		c.add(password);
		
		JButton jb=new JButton("ȷ��");
		jb.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				if(name.getText().trim().length()==0||new String(password.getPassword()).trim().length()==0){
					JOptionPane.showMessageDialog(null, "�û������벻����Ϊ��");
					return;
				}
				if(name.getText().trim().equals("mr")&&new String(password.getPassword()).trim().equals("mrsoft")){
					JOptionPane.showMessageDialog(null, "��¼�ɹ�");
				}
				else{
					JOptionPane.showMessageDialog(null, "�û������������");
				}
			}
		});
		jb.setBounds(80, 90, 60, 18);
		c.add(jb);

		final JButton button = new JButton();
		button.setText("����");
		button.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				// TODO �Զ����ɷ������
				name.setText("");
				password.setText("");
			}
		});
		button.setBounds(150, 90, 60, 18);
		getContentPane().add(button);
		setVisible(true);
	}
	
	
}
	

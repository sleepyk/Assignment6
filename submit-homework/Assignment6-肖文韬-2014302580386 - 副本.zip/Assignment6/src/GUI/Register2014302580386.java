package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Register2014302580386 extends JFrame{
	Container c  = getContentPane();
	
	public Register2014302580386(){
		setTitle("Register");
		c.setLayout(null);
		setBounds(300, 200, 200, 300);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		
		
		JLabel jl=new JLabel("�������û�����");
		jl.setBounds(25, 20, 90, 20);
		final JTextField name=new JTextField();
		name.setBounds(90, 40, 125, 40);
		JLabel j2=new JLabel("���������룺");
		jl.setBounds(25, 80, 90, 20);
		final JTextField password=new JTextField();
		name.setBounds(90, 100, 125, 40);
		JLabel j3=new JLabel("���������䣺");
		jl.setBounds(25, 140, 90, 20);
		final JTextField mail=new JTextField();
		name.setBounds(90, 160, 125, 40);
		
		c.add(jl);
		c.add(j2);
		c.add(j3);
		
		
		final JButton jb1 = new JButton("ȷ��");
		jb1.setBounds(40, 240, 40, 20);
		jb1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				if(name.getText().trim().length()==0||new String(password.getText()).trim().length()==0){
					JOptionPane.showMessageDialog(null, "�û������벻����Ϊ��");
					return;
				}
				else{
					JOptionPane.showMessageDialog(null, "ע��ɹ�");
				}
			}
		});
		c.add(jb1);
		
		
		
		final JButton jb2 = new JButton("ȡ��");
		jb2.setBounds(120, 240, 40, 20);
		jb2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				// TODO �Զ����ɷ������
				name.setText("");
				password.setText("");
			}
		});
		c.add(jb2);
		
		setVisible(true);
	}
}

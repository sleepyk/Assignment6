package GUI;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class MainGUI2014302580386 extends JFrame{
	Container c = getContentPane();
	
	public MainGUI2014302580386(){
		setTitle("�����");
		c.setLayout(null);
		setBounds(300, 200, 200, 300);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		
		JTextField petmes = new JTextField();
		
		JButton jb = new JButton("����");
		jb.setBounds(0, 0, 0, 0);
		jb.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO �Զ����ɵķ������
				
			}
			
		});
		
		JPanel pet1 = new JPanel();
		JPanel pet2 = new JPanel();
		JPanel pet3 = new JPanel();
		JPanel pet4 = new JPanel();
		JPanel pet5 = new JPanel();
		JPanel pet6 = new JPanel();
		JPanel pet7 = new JPanel();
		JPanel pet8 = new JPanel();
		JPanel pet9 = new JPanel();
		JPanel pet10 = new JPanel();
		
		pet1.add(petmes);
		pet1.add(jb);
		pet2.add(petmes);
		pet2.add(jb);
		pet3.add(petmes);
		pet3.add(jb);
		pet4.add(petmes);
		pet4.add(jb);
		pet5.add(petmes);
		pet5.add(jb);
		pet6.add(petmes);
		pet6.add(jb);
		pet7.add(petmes);
		pet7.add(jb);
		pet8.add(petmes);
		pet8.add(jb);
		pet9.add(petmes);
		pet9.add(jb);
		pet10.add(petmes);
		pet10.add(jb);
		
		c.add(pet1);
		c.add(pet2);
		c.add(pet3);
		c.add(pet4);
		c.add(pet5);
		c.add(pet6);
		c.add(pet7);
		c.add(pet8);
		c.add(pet9);
		c.add(pet10);
		
		
	}

}

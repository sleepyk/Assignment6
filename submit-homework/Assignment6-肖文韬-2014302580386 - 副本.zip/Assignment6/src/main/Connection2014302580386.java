package main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connection2014302580386 {
	Connection con;
	public Connection getConnection(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("");
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		try{
			con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/assignment3","root","1423");
			System.out.println("");
		}catch(SQLException e){
			e.printStackTrace();
		}
		return con;
	}
}

package main;

import GUI.login2014302580386;

public class Main2014302580386 {
	public static void main(String[] args){
		new login2014302580386();
	}
}
